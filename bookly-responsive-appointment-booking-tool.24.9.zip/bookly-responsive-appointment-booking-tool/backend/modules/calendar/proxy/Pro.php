<?php
namespace Bookly\Backend\Modules\Calendar\Proxy;

use Bookly\Lib;

/**
 * @method static void renderServicesFilterOption()
 */
abstract class Pro extends Lib\Base\Proxy
{

}