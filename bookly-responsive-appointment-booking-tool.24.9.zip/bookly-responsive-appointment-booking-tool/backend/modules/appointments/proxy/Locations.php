<?php
namespace Bookly\Backend\Modules\Appointments\Proxy;

use Bookly\Lib;

/**
 * @method static void renderFilter() Render location filter on appointments list page.
 */
abstract class Locations extends Lib\Base\Proxy
{

}