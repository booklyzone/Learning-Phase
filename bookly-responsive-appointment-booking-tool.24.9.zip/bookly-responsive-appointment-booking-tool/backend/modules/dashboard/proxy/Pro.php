<?php
namespace Bookly\Backend\Modules\Dashboard\Proxy;

use Bookly\Lib;

/**
 * @method static void renderAnalytics() Render analytics section.
 */
abstract class Pro extends Lib\Base\Proxy
{

}