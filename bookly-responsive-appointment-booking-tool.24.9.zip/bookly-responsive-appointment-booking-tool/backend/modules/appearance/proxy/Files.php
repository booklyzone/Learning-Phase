<?php
namespace Bookly\Backend\Modules\Appearance\Proxy;

use Bookly\Lib;

/**
 * @method static void renderAppearance() Render button browse in Appearance
 */
abstract class Files extends Lib\Base\Proxy
{

}