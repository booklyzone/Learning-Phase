<?php
namespace Bookly\Backend\Modules\Appearance\Proxy;

use Bookly\Lib;

/**
 * @method static void renderCustomerInformation() render "customer information" input
 */
abstract class CustomerInformation extends Lib\Base\Proxy
{
}