<?php
namespace Bookly\Backend\Modules\Appearance\Proxy;

use Bookly\Lib;

/**
 * @method static void renderCustomFields() render "custom fields" input
 */
abstract class CustomFields extends Lib\Base\Proxy
{
}