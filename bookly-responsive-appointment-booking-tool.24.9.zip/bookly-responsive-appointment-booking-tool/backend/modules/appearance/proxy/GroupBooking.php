<?php
namespace Bookly\Backend\Modules\Appearance\Proxy;

use Bookly\Lib;

/**
 * @method static void renderNOP() Render number of persons select in Service step.
 */
abstract class GroupBooking extends Lib\Base\Proxy
{

}