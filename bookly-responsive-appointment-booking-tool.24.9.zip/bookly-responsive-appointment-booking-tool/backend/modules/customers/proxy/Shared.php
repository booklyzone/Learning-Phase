<?php
namespace Bookly\Backend\Modules\Customers\Proxy;

use Bookly\Lib;

/**
 * @method static void mergeCustomers( int $target_id, array $ids ) Merge customers.
 */
abstract class Shared extends Lib\Base\Proxy
{

}