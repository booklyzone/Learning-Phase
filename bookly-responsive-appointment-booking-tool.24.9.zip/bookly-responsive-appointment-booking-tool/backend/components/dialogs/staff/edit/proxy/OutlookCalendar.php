<?php
namespace Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy;

use Bookly\Lib;

/**
 * @method static void renderCalendarSettings( array $tpl_data ) Render Outlook Calendar settings.
 */
abstract class OutlookCalendar extends Lib\Base\Proxy
{

}