<?php
namespace Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy;

use Bookly\Lib;

/**
 * @method static void renderPaymentGatewaysHelp() Render help message.
 */
abstract class CustomerGroups extends Lib\Base\Proxy
{

}