<?php
namespace Bookly\Backend\Components\Dialogs\Staff\Categories\Proxy;

use Bookly\Lib as BooklyLib;

/**
 * @method static void renderDialog()
 * @method static void renderAdd()
 */
abstract class Pro extends BooklyLib\Base\Proxy
{
}