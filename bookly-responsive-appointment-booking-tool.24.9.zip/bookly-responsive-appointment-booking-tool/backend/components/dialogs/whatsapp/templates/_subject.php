<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<input type="hidden" name="notification[subject]" value=""/>
<input type="hidden" name="notification[gateway]" value="whatsapp"/>
<input type="hidden" name="notification[settings][whatsapp][template]" value=""/>
<input type="hidden" name="notification[settings][whatsapp][language]" value=""/>