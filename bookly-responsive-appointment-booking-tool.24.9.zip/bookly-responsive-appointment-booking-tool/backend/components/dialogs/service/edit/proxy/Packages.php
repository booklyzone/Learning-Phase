<?php
namespace Bookly\Backend\Components\Dialogs\Service\Edit\Proxy;

use Bookly\Lib;

/**
 * @method static void renderSubForm( array $service, array $simple_services )
 */
abstract class Packages extends Lib\Base\Proxy
{

}