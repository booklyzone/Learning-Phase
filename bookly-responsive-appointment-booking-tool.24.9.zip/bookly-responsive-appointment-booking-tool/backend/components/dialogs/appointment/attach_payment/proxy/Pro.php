<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\AttachPayment\Proxy;

use Bookly\Lib;

/**
 * @method static void renderAttachPaymentDialog() Render attach payment dialog.
 */
abstract class Pro extends Lib\Base\Proxy
{

}