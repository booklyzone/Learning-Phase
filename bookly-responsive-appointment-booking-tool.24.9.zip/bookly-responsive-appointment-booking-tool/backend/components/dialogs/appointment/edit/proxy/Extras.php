<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\Edit\Proxy;

use Bookly\Lib;

/**
 * @method static array getMaxDurationExtras( array $extras ) Prepare extras list for day schedule.
 */
abstract class Extras extends Lib\Base\Proxy
{

}