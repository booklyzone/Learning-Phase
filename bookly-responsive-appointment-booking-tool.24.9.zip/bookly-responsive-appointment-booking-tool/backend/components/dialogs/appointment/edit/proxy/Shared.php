<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\Edit\Proxy;

use Bookly\Lib;

/**
 * @method static array prepareL10n( array $l10n ) Prepare L10n object
 * @method static array prepareDataForPackage( array $data )
 */
abstract class Shared extends Lib\Base\Proxy
{

}