<?php
namespace Bookly\Backend\Components\TinyMce\Proxy;

use Bookly\Lib;

/**
 * @method static void renderStaffCabinetSettings() Render settings in Staff Cabinet shortcode.
 */
abstract class SpecialHours extends Lib\Base\Proxy
{

}