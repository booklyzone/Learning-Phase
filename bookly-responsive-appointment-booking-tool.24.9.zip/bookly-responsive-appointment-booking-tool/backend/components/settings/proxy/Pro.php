<?php
namespace Bookly\Backend\Components\Settings\Proxy;

use Bookly\Lib;

/**
 * @method static void renderPurchaseCode( $blog_id = null ) Render purchase code
 */
abstract class Pro extends Lib\Base\Proxy
{

}